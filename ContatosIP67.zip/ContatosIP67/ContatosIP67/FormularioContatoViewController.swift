//
//  ViewController.swift
//  ContatosIP67
//
//  Created by ios7818 on 03/11/18.
//  Copyright © 2018 Caelum. All rights reserved.
//

import UIKit

import CoreLocation

class FormularioContatoViewController: UIViewController,
    UINavigationControllerDelegate,
    UIImagePickerControllerDelegate
{
    
    var dao: ContatoDAO
    var contato: Contato!
    var delegate:FormularioContatoViewControllerDelegate?
    
    required init?(coder aDecoder: NSCoder){
        self.dao = ContatoDAO.sharedInstance()
        super.init(coder: aDecoder)
    }
    
    @IBOutlet var nome:     UITextField!
    @IBOutlet var telefone: UITextField!
    @IBOutlet var endereco: UITextField!
    @IBOutlet var site:     UITextField!
    @IBOutlet var latitude:  UITextField!
    @IBOutlet var longitude: UITextField!
    @IBOutlet var imageView: UIImageView!
    @IBOutlet var loading: UIActivityIndicatorView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        if contato != nil{
            self.nome.text = contato.nome
            self.telefone.text = contato.telefone
            self.endereco.text = contato.endereco
            self.site.text = contato.site
            
            self.longitude.text = contato.longitude?.description
            self.latitude.text = contato.latitude?.description
            
            if (contato.foto) != nil{
                self.imageView.image = self.contato.foto
                
            }
            
            let botaoAlterar = UIBarButtonItem(title: "Confirmar", style: .plain, target: self,
                                               action: #selector(atualizaContato))
            
            self.navigationItem.rightBarButtonItem = botaoAlterar;
            
            
        }
        
        
        self.imageView.layer.cornerRadius = self.imageView.frame.size.width / 2
        self.imageView.layer.masksToBounds = true

        
        let tap = UITapGestureRecognizer(target: self, action: #selector(selecionaFoto(sender:)))
        
        self.imageView.addGestureRecognizer(tap)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    @IBAction func criaContato(){
        self.pegaDadosDoFormulario();
        dao.adiciona(contato);
        self.delegate?.contatoAdicionado(contato)
        _=self.navigationController?.popViewController(animated: true)
        
        dao.saveContext();
    }
    
    func atualizaContato(){
        pegaDadosDoFormulario()
        self.delegate?.contatoAtualizado(contato)
        _=self.navigationController?.popViewController(animated: true)
        dao.saveContext();
    }
    
    func pegaDadosDoFormulario () {
        if contato == nil{
            self.contato = dao.novoContato()
        }
        self.contato.nome = self.nome.text!
        self.contato.telefone = self.telefone.text!
        self.contato.endereco = self.endereco.text!
        self.contato.site = self.site.text!
        self.contato.foto = self.imageView.image
        
        if let latitude = Double(self.latitude.text!) {
            self.contato.latitude = latitude as NSNumber
        }
        if let longitude = Double(self.longitude.text!) {
            self.contato.longitude = longitude as NSNumber
        }
        
        
        
    }

    func selecionaFoto(sender: AnyObject){
        if UIImagePickerController.isSourceTypeAvailable(.camera){
            //camera
        }else {
            let imagePicker = UIImagePickerController()
            imagePicker.sourceType = .photoLibrary
            imagePicker.allowsEditing = true
            imagePicker.delegate = self
            
            self.present(imagePicker, animated: true, completion:nil)
        }
    }
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any])
    {
        if let imageSelecionada = info [UIImagePickerControllerEditedImage] as? UIImage {
            self.imageView.image = imageSelecionada
            self.imageView.layer.cornerRadius = self.imageView.frame.size.width / 2
            self.imageView.layer.masksToBounds = true
            
        }
        
        picker.dismiss(animated: true, completion: nil)
    }
    
    @IBAction func buscarCoordenadas(sender: UIButton){
        
        guard let text = endereco.text, !text.isEmpty else {
            let alerta = UIAlertController(title: "Erro de Consistencia",
                                           message: "Favor preencher o campo de Endereco",
                                           preferredStyle: .alert)
            let action = UIAlertAction(title: "OK", style: .default, handler: nil)
            alerta.addAction(action)
            self.present(alerta,animated: true, completion: nil)
            
            return
        }
        
        self.loading.startAnimating();
        sender.isEnabled = false;
        
        let geocoder = CLGeocoder()
        
        geocoder.geocodeAddressString(self.endereco.text!) { (resultado, error) in
            if error == nil && (resultado?.count)!>0 {
                let placemark = resultado![0]
                let coordenada = placemark.location!.coordinate
                
                self.latitude.text = coordenada.latitude.description
                self.longitude.text = coordenada.longitude.description
                
                self.loading.stopAnimating();
                sender.isEnabled = true;
            }
        }
    }
    
}

