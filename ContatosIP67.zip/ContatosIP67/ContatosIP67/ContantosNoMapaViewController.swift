//
//  ContantosNoMapaViewController.swift
//  ContatosIP67
//
//  Created by ios7531 on 24/11/18.
//  Copyright © 2018 Caelum. All rights reserved.
//

import UIKit
import MapKit

class ContantosNoMapaViewController: UIViewController
{
    @IBOutlet weak var mapa: MKMapView!
    
    let locationManager = CLLocationManager()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.locationManager.requestWhenInUseAuthorization()
        
        let botaoLocalizacao = MKUserTrackingBarButtonItem(mapView: self.mapa)
        
        self.navigationItem.rightBarButtonItem = botaoLocalizacao
    }
}
