//
//  ContatosNoMapaViewController.swift
//  ContatosIP67
//
//  Created by ios7531 on 24/11/18.
//  Copyright © 2018 Caelum. All rights reserved.
//

import UIKit
import MapKit

class ContatosNoMapaViewController: UIViewController, MKMapViewDelegate {
    
    @IBOutlet weak var mapa: MKMapView!
    var contatos: [Contato]  = Array()
    let dao:ContatoDAO = ContatoDAO.sharedInstance()
    
    let locationManager = CLLocationManager()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        self.mapa.delegate = self
        
        self.locationManager.requestWhenInUseAuthorization()
        
        let botaoLocalizacao = MKUserTrackingBarButtonItem(mapView: self.mapa)
        
        self.navigationItem.rightBarButtonItem = botaoLocalizacao
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func mapView(_ mapView: MKMapView, viewFor annotation: MKAnnotation) -> MKAnnotationView? {
        if annotation is MKUserLocation {
            return nil
        }
        
        let identifier:String = "pino"
        var pino:MKPinAnnotationView
        
        if let resuablepin = mapView.dequeueReusableAnnotationView(withIdentifier: identifier) as? MKPinAnnotationView
        { pino = resuablepin}
        else
        { pino = MKPinAnnotationView(annotation: annotation, reuseIdentifier: identifier)}
        
        if let contato = annotation as? Contato {
            pino.pinTintColor  = UIColor.black
            pino.canShowCallout = true
            
            let frame = CGRect(x: 0.0, y: 0.0, width: 30.0, height: 30.0)
            let imagemContato = UIImageView(frame: frame)
            imagemContato.layer.cornerRadius = imagemContato.frame.size.width / 2
            imagemContato.layer.masksToBounds = true

            imagemContato.image = contato.foto
            
            pino.leftCalloutAccessoryView = imagemContato;
        
            
        }
        return pino
    }
    
    func mapView(_ mapView: MKMapView, didSelect view: MKAnnotationView) {
        let pinToZoomOn = view.annotation
        
        let span = MKCoordinateSpanMake(0.5, 0.5)
        
        let region = MKCoordinateRegion(center: pinToZoomOn!.coordinate, span: span)
        mapView.setRegion(region, animated: true)
        
    }
    
    
    override func viewWillAppear(_ animated: Bool) {
        self.contatos = dao.listaTodos()
        self.mapa.addAnnotations(self.contatos)
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        self.mapa.removeAnnotations(self.contatos)
    }
}
